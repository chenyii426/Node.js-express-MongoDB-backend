module.exports = {
    'secret':'nodeauthsecret',
    'database': 'mongodb://localhost/Sci-CAFE'
  };